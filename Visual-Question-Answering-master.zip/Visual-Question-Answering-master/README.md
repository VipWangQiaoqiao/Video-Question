# Visual-Question-Answering
This is the demo for VQA.

The data this program need can download from http://visualqa.org/download.html

This program need the mxnet dependency. That you need install it first.
The websit is :http://mxnet.readthedocs.io/en/latest/how_to/build.html
